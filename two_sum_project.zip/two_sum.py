def two_sum(nums: list[int], target: int) -> list[int]:
    """Return indices of the two numbers in nums that add up to target."""
    seen: dict[int, int] = {}
    for index, value in enumerate(nums):
        complement = target - value
        if complement in seen:
            return [seen[complement], index]
        seen[value] = index
    return []


def has_pair_with_sum(nums: list[int], target: int) -> bool:
    """Check whether any two distinct elements in nums sum to target."""
    indices = two_sum(nums, target)
    return len(indices) == 2


if __name__ == "__main__":
    sample = [2, 7, 11, 15]
    result = two_sum(sample, 9)
    print(f"Indices for target 9: {result}")
